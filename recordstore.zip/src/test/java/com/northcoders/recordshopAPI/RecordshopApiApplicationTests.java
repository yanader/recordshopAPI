package com.northcoders.recordshopAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordshopApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.northcoders.recordshopAPI.model;

public enum Genre {
    ROCK,
    COUNTRY,
    DANCE,
    SOUL,
    POP,
    JAZZ,
    CLASSICAL
}
